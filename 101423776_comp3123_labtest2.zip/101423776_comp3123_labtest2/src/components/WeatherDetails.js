import React from 'react';

const WeatherDetails = ({ weatherData }) => {
  if (!weatherData) {
    return <p>Loading weather data...</p>;
  }

  const { weather, main, wind, sys, name } = weatherData;

  return (
    <div className="weather-info">
      <h2>{name}, {sys.country}</h2>
      <img
        src={`https://openweathermap.org/img/wn/${weather[0].icon}@2x.png`}
        alt={weather[0].description}
      />
      <p><strong>🌡️ Temperature:</strong> {main.temp.toFixed(1)}°C</p>
      <p><strong>⛅ Condition:</strong> {weather[0].description}</p>
      <p><strong>💧 Humidity:</strong> {main.humidity}%</p>
      <p><strong>💨 Wind Speed:</strong> {wind.speed.toFixed(1)} m/s</p>
    </div>
  );
};

export default WeatherDetails;
